args = commandArgs(TRUE)
s    = as.double(args[1])


source("Simulation_LowDim_setting1.R")
lowDim_single(s)